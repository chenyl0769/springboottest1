package com.cyl.springboottest1.fli;

public interface Group2 {
}
